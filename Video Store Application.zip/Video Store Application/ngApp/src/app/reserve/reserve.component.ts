import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reserve',
  templateUrl: './reserve.component.html',
  styleUrls: ['./reserve.component.css'],
  inputs: ['video']
})
export class ReserveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
