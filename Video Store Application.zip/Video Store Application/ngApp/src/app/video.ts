export class Video {
    _id: String;
    id: Number;
    title: String;
    runtime: String;
    genre: String;
    rating: String;
    director: String;
    status: String;
}
